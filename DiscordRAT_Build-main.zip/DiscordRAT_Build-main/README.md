The source code it here: https://github.com/hassamohammed/Discord_RAT_Source_og
